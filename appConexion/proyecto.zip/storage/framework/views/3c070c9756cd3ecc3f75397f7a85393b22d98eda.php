  <!--SOCIAL NETWORKS AREA-->
    <section class="fun-fact-area center white relative padding-100-70" id="fact">
        <div class="area-bg" data-stellar-background-ratio="0.6"></div>
        <div class="container">
            <div class="row">
                
                <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="single-fun-fact mb30 wow fadeInUp" data-wow-delay="0.1s">
                        <a href="<?php echo e($red->link); ?>" target="_blank"><i class="<?php echo e($red->logo); ?> fa-5x" ></i></a>
                        <!--<h3 class="font60 xs-font26"><span class="counter">20</span>k</h3>-->
                        <p class="font600"><?php echo e($red->name); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </section>
    <!--SOCIAL NETWORKS AREA END-->