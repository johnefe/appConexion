<!--WELCOME SLIDER AREA-->
        <div class="welcome-slider-area white font16">
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="welcome-single-slide">
                <div class="slide-bg-overlay" style=" background: rgba(0, 0, 0, 0) url('<?php echo e(asset('storage/img/slider/'.$slide->url_img)); ?>') no-repeat scroll center center / cover;"></div>
                <div class="welcome-area">
                    <div class="container">
                        <div class="row flex-v-center">
                            <div class="col-md-8 col-lg-7 col-sm-12 col-xs-12">
                                <div class="welcome-text">
                                    <h1><?php echo e($slide->title); ?></h1>
                                    <p><?php echo e($slide->body); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--WELCOME SLIDER AREA END-->