<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
     <div class="row">
         <div class="col-lg-12">
            	<h1 class="page-header">Nuestros trabajos</h1>
            	<br><br>     
    	</div>
	</div>
	<div class="row">
        <!-- for each slider-->
        <?php echo $__env->make('messages._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php $__currentLoopData = $make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!--<div class="col-lg-12">
            <div class="form-group text-center">
                <a href="/admin/makes/<?php echo e($make->id); ?>/edit" class="btn btn-default btn-circle"><span class="fa fa-pencil "></span></a>
            </div>
        </div>-->
        <div class="col-lg-4">
            
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                  <?php echo e($make->title); ?>

                </div>
                <div class="panel-body">
                     
                    <div class="row">
                        <div class="col-lg-12">
                            <form role="form">
                                        
                                <div class="form-group">
                                    <img src="<?php echo e(asset('storage/img/blog/sub-blog/'.$make->url_img)); ?>" width="100%;" height="250px">
                                </div>
                            </form>
                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-6">
                                         <div class="form-group text-center">
                                            <a href="/admin/makes/<?php echo e($make->id); ?>/edit" class="btn btn-default btn-circle"><span class="fa fa-pencil "></span></a>
                                        </div>
                                </div>
                                <div class="col-lg-6">
                                         <div class="form-group text-center">
                                            <?php echo Form::open(['route'=>['maker.destroy',$make->id],'method'=>'DELETE']); ?>

                                                <button type="submit" class=" btn btn-default btn-circle" ><span class="fa fa-trash fa-1x"></span></button>
                                            <?php echo Form::close(); ?>

                                        </div>
                                         
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>