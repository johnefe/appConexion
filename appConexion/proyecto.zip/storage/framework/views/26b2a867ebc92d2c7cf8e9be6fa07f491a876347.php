 <section class="section-padding about-area" id="about">
        <div class="container">

            <?php $__currentLoopData = $contentVideo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row flex-v-center">
                <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
                    <div class="about-content xs-mb50 wow fadeIn">
                        <h3 class="xs-font20 mb30 r"><?php echo e($h->title); ?> <i class="<?php echo e($h->icon); ?>"></i> </h3>
                        <p><?php echo e($h->body); ?></p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 col-md-offset-1 col-lg-offset-1 col-sm-12 col-xs-12">
                    <div class="video-promo-details wow fadeIn">
                        <div class="video-promo-content">
                            <span data-video-id="<?php echo e($h->link_video); ?>" class="video-area-popup mb30"><i class="fa fa-play"></i></span>
                        </div>
                        <img src="<?php echo e(asset('storage/img/about/'.$h->url_img)); ?>" alt="">
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>