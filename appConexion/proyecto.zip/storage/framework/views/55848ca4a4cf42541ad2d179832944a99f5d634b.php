 <!--ABOUT TOP CONTENT AREA-->
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-12 col-xs-12">
                    <div class="text-center wow fadeIn">
                        <h2 class="xs-font20"><?php echo e($info->title); ?></h2>
                        <p><?php echo e($info->body); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--ABOUT TOP CONTENT AREA END-->