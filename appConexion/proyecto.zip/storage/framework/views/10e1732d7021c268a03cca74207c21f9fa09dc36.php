<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
     <div class="row">
         <div class="col-lg-12">
            	<h1 class="page-header">CREAR NUEVA DIAPOSITIVA</h1>
           		<br><br>     
    	</div>
	</div>
	<div class="row">
                  
        <div class="col-lg-6 col-lg-offset-3">
        	
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                   DATOS DIAPOSITIVA
                </div>
                <div class="panel-body">
                	
                    <div class="row">
                    	<!-- formualario para crear nueva diapositiva-->
                    	<?php echo Form::open(['id'=>'dataForm','url'=> '/slider.store', 'method'=>'POST','files' => true]); ?>

                    	<div class="col-lg-12">
                            
                           	<?php echo $__env->make('admin.slider.form.formSlider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           	
                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="submit" class="form-control btn btn-success" name="" value="REGISTRAR">
                                    </div>
                                </div>
                            </div>   
                        </div>
                        <?php echo Form::close(); ?>

                        <!-- end formualario para crear nueva diapositiva-->
                    </div>
                    
                </div>
            </div>
            
        </div>

    </div>



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>