<?php $__env->startSection('content'); ?>
<div id="page-wrapper" class="bg-gray-2">
     <div class="row">
         <div class="col-lg-12">
            	<h1 class="page-header titulo-3">Actualizar información básica</h1>
   
    	</div>
	</div>
	<div class="row">
        <?php echo $__env->make('messages._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>          
        <div class="col-lg-6 col-lg-offset-3">
            
            <div class="panel panel-default">
                <div class="panel-heading text-center bg-blue-1">
                   <h4 class="titulo-4">DATOS<h4>
                </div>
                <div class="panel-body">
                    
                    <div class="row texto">
                        <!-- formualario para crear nueva diapositiva-->
                   
                        <?php echo Form::model($date,['route'=> ['date.update',$date->id], 'method'=>'PUT','files' => true]); ?>

                        <div class="col-lg-12">
                            
                           <div class="form-group">
                                <?php echo Form::label('Nombre:'); ?>

                                <?php echo Form::text('title',null,['class'=>'form-control','placeholder'=>'Nombre de la aplicación']); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('Dirección:'); ?>

                                <?php echo Form::text('address',null,['class'=>'form-control','placeholder'=>'Dirección']); ?>

                            </div>
                             <div class="form-group">
                                <?php echo Form::label('Teléfono:'); ?>

                                <?php echo Form::text('phone',null,['class'=>'form-control','placeholder'=>'Dirección']); ?>

                            </div>
                             <div class="form-group">
                                <?php echo Form::label('Correo electrónico:'); ?>

                                <?php echo Form::text('email',null,['class'=>'form-control','placeholder'=>'Correo electrónico']); ?>

                            </div>
                             <div class="form-group">
                                <?php echo Form::label('Ciudad:'); ?>

                                <?php echo Form::text('city',null,['class'=>'form-control','placeholder'=>'Ciudad']); ?>

                            </div>
                            <div class="form-group" id="divMain">
                                
                                <div id="divInputLoad">
                                    <?php echo Form::label('Escoge una imagen'); ?>

                                    <?php echo Form::file('logo',['class'=>'form-control', 'id'=>'logo', 'accept'=>'image/*']); ?>

                                    <div class="form-group text-center img-prev"  id="file-preview-zone">
                                    </div>
                                </div>
                                <div  id="prev">
                                    <img src="<?php echo e(asset('storage/img/logo/'.$date->logo)); ?>" width="100%;" height="230px">
                                </div>
                            </div>
                            
                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="submit" class="form-control btn bg-blue-1 titulo-4 name="" value="ACTUALIZAR">
                                    </div>
                                </div>
                                
                            </div>   
                        </div>
                        <?php echo Form::close(); ?>

                        <!-- end formualario para crear nueva diapositiva-->
                    </div>
                    
                </div>
            </div>
            
        </div>

    </div>
</div>
<script>
    function readFile(input) {
        document.getElementById('file-preview-zone').innerHTML="";

        if (input.files && input.files[0]) {
            var reader = new FileReader();
            //previewZone. removeChild(filePreview);
            reader.onload = function (e) {
                var filePreview = document.createElement('img');
                filePreview.id = 'file-preview';
                //e.target.result contents the base64 data from the image uploaded
                filePreview.src = e.target.result;
                console.log(e.target.result);
 
                var previewZone = document.getElementById('file-preview-zone');
                previewZone.appendChild(filePreview);
                //document.getElementById('file-preview-zone').innerHTML=filePreview;
            }
 
            reader.readAsDataURL(input.files[0]);
        }
    }
 
    var fileUpload = document.getElementById('logo');
    fileUpload.onchange = function (e) {
        document.getElementById("prev").innerHTML="";
        readFile(e.srcElement);
    }
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>