<?php $__env->startSection('content'); ?>
<div id="page-wrapper" class="bg-gray-2">

     <div class="row">

         <div class="col-lg-12">
            	<h1 class="page-header titulo-3">NUEVA DIAPOSITIVA</h1>
           		<br><br>     
    	</div>
	</div>
	<div class="row">
                  
        <div class="col-lg-6 col-lg-offset-3">
        	
            <div class="panel panel-default">
                <div class="panel-heading text-center bg-blue-1">
                   <label class="titulo-4">DATOS DIAPOSITIVA</label>
                </div>
                <div class="panel-body">
                	<?php echo $__env->make('messages._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="row">
                    	<!-- formualario para crear nueva diapositiva-->
                    	<?php echo Form::open(['route'=> 'slider.store', 'method'=>'POST','files' => true]); ?>

                          <?php echo csrf_field(); ?>
                    	<div class="col-lg-12">
                            
                           	<?php echo $__env->make('admin.slider.form.formSlider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                           	
                        </div>
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="submit" class="form-control btn titulo-4 bg-blue-1" name="" value="REGISTRAR">
                                    </div>
                                </div>
                            </div>   
                        </div>
                        <?php echo Form::close(); ?>

                        <!-- end formualario para crear nueva diapositiva-->
                    </div>
                    
                </div>
            </div>
            
        </div>

    </div>



</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>