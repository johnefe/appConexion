<?php $__env->startSection('content'); ?>
<div id="page-wrapper" class="bg-gray-2"><br><br><br>
	<div class="row">
		<div class="col-lg-4 col-lg-offset-4">
                    <div class="panel panel-default">
                        <div class="panel-heading bg-blue-1">
                            <h4 class="titulo-4"><i class="fa fa-envelope fa-fw"></i> Correos electrónicos.</h4>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="list-group">
                            	<?php $__currentLoopData = $mails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#" class="list-group-item">
                                    <i class="fa fa-check-circle-o  fa-fw"></i><?php echo e($mail->email); ?>

                                    <span class="pull-right text-muted small"><em><?php echo e($mail->created_at); ?></em>
                                    </span>
                                </a>
                               	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <!-- /.list-group -->
                            <!--<a href="#" class="btn btn-default btn-block">Descargar en archivo plano</a>-->
                             <a href="<?php echo e(URL::to('downloadExcel/xls')); ?>"><button class="btn btn-success">Download Excel xls</button></a>
                        </div>

	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>