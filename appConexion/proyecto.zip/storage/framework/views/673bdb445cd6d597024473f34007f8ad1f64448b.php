<!--FEATURES TOP AREA-->
    <section class="features-top-area" id="features">
        <div class="container">
            <div class="row promo-content">
                <?php $__currentLoopData = $threeHabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Habilities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 text-center">
                    <div class="text-icon-box mb20 xs-mb0 wow fadeInUp padding30" data-wow-delay="0.1s">
                        <div class="box-icon features-box-icon">
                            <i class="<?php echo e($Habilities->link_icon); ?>"></i>
                        </div>
                        <h3 class="box-title"><?php echo e($Habilities->title); ?></h3>
                        <p><?php echo e($Habilities->body); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!--FEATURES TOP AREA END-->