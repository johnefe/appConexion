<header class="top-area" id="home">
   <div class="header-top-area" id="scroolup">
            <!--MAINMENU AREA-->
            <div class="mainmenu-area" id="mainmenu-area">
                <div class="mainmenu-area-bg"></div>
                <nav class="navbar">
                    <div class="container">
                        <div class="navbar-header">
                            <a href="#home" class="navbar-brand" style="color: #fff;"><!--<img src="assest/img/logo.png" alt="logo">-->Conexión Gráfica</a>
                        </div>
                        <div id="main-nav" class="stellarnav">
                            <ul id="nav" class="nav navbar-nav pull-right">
                                <li class="active"><a href="/">Inicio</a></li>
                                <li><a href="/#features">Nosotros</a></li>
                                <li><a href="/#trabajos">Nuestros Trabajos</a></li>
                                <li><a href="/#promociones">Promociones</a></li>
                                <li><a href="/#contact">Contáctanos</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
            <!--END MAINMENU AREA END-->
        </div>  
       
</header>
<!--ABILITIES OUR AREA-->
    <section class="blog-feed-area bg-extra-light-gray padding30" id="trabajos">
        <div class="container">
             <?php $__currentLoopData = $make; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-md-8 col-lg-8 col-md-offset-2 col-lg-offset-2 col-sm-12 col-xs-12">
                    <div class="area-title text-center  fadeIn">
                       
                        <h2><?php echo e($make->title); ?></h2>
                            </div>
                </div>
            </div>
            <div class="row">
              
             
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12 mty-10">
                    <div class="single-blog-item sm-mb30 xs-mb30 fadeInUp" data-wow-delay="0.2s">
                        <div class="blog-thumb">
                            <a href="blog.html"><img src="<?php echo e(asset('storage/img/promotions/'.$make->link_image)); ?>" class="img-service" alt=""></a>
                        </div>
                    </div>
                    
                </div>
                <div class="col-md-8 col-lg-8 col-sm-6 col-xs-12 mty-10">
                     <p><?php echo e($make->body); ?></p>
                </div>
                <div class="col-md-8 col-lg-8 col-sm-6 col-xs-12 mty-10">
                   
                    <span class="course-price">PRECIO: $<?php echo e($make->price); ?></span></p>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            </div>
        </div>
    </section>
    <!--ABILITIES OUR AREA END-->
<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('layouts.promotions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>