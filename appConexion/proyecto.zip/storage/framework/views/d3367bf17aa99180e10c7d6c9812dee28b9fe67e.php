 <!--FOOER AREA-->
    <footer class="footer-area relative">
        <div class="footer-top-area padding-80-80 bg-dark">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
                        <div class="single-footer footer-about sm-mb50 xs-mb50 sm-center xs-center">
                            
                            <?php $__currentLoopData = $date; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="footer-logo mb30">
                                <a href="www.conexiongraficapasto.com" target="_blank" style="color: #fff;"><?php echo e($date->title); ?></a>
                            </div>
                            
                          
                            <p><?php echo e($date->phone); ?></p>
                            <p><?php echo e($date->address); ?></p>
                            <p><?php echo e($date->email); ?></p>
                              <p><?php echo e($date->city); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-2 col-lg-2 col-sm-4 col-xs-12">
                        <div class="single-footer footer-list white xs-center xs-mb50">
                            <ul>
                                <?php $__currentLoopData = $redes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e($red->link); ?>" target="_blank"><?php echo e($red->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-5 col-lg-5 col-sm-8 col-xs-12">
                        <div class="single-footer footer-subscribe white xs-center">
                            <h3 class="mb30 xs-font18">Suscríbete gratis ahora!</h3>
                            <p>Envíanos tu correo y recibiras promociones que puedes aprovechar, noticias y muchas cosas interesantes.</p>
                           
                            <div class="subscriber-form-area mt50 wow fadeIn">

                                <form  method="post" action="<?php echo e(url('news')); ?>" enctype="multipart/form-data" class="subscriber-form">
                                <?php echo csrf_field(); ?>
                                    
                                    <input type="email" name="email" placeholder="tucorreo@example.com">
                                    <button type="submit" class="plus-btn"><i class="fa fa-paper-plane-o"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-dark-low white">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="footer-copyright text-center wow fadeIn">
                            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                                Copyright &copy;<script>document.write(new Date().getFullYear());</script> Todos los derechos son reservados | <a href="https://conexiongraficapasto.com" target="_blank">www.conexióngraficapasto.com</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--FOOER AREA END-->