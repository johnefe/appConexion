@extends('admin.base')

@section('content')
    @include('admin.home')
@stop