 <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Bienvenido admin.</h1><small>Aqui puedes gestionar todo la información que se puede ver en el inicio de tu página. </small>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
</div>
        <!-- /#page-wrapper -->