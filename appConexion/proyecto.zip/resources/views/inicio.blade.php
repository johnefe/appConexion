@extends('layouts.base')

@section('content')
	@include('layouts.header')
    @include('layouts.features')
    @include('layouts.content_area')
    @include('layouts.social_networks')
    @include('layouts.habilities')
    @include('layouts.about')
    @include('layouts.promotions')
    @include('layouts.contact')
    @include('layouts.footer')
@stop