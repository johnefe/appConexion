 <!--====== SCRIPTS JS ======-->
    <script src="/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="/js/vendor/bootstrap.min.js"></script>

    <!--====== PLUGINS JS ======-->
    <script src="/js/vendor/jquery.easing.1.3.js"></script>
    <script src="/js/vendor/jquery-migrate-1.2.1.min.js"></script>
    <script src="/js/vendor/jquery.appear.js"></script>
    <script src="/js/owl.carousel.min.js"></script>
    <script src="/js/stellar.js"></script>
    <script src="/js/waypoints.min.js"></script>
    <script src="/js/jquery.counterup.min.js"></script>
    <script src="/js/wow.min.js"></script>
    <script src="/js/jquery-modal-video.min.js"></script>
    <script src="/js/stellarnav.min.js"></script>
    <script src="/js/placeholdem.min.js"></script>
    <script src="/js/contact-form.js"></script>
    <script src="/js/jquery.ajaxchimp.js"></script>
    <script src="/js/jquery.sticky.js"></script>

    <!--===== ACTIVE JS=====-->
    <script src="/js/main.js"></script>

    <!--===== MAPS JS=====-->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTS_KEDfHXYBslFTI_qPJIybDP3eceE-A&sensor=false"></script>
    <script src="/js/maps.active.js"></script>