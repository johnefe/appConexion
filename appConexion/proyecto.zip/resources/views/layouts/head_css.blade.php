<!-- head_css-->
	<link href="/css/plugins.css" rel="stylesheet">
	<link href="/css/theme.css" rel="stylesheet">
	<link href="/css/icons.css" rel="stylesheet">

	 <!--====== MAIN STYLESHEETS ======-->
	<link href="/css/style.css" rel="stylesheet">
	<link href="/css/responsive.css" rel="stylesheet">
	<script src="/js/modernizr-2.8.3.min.js"></script>
<!-- end head_css-->